                                  -----------
                                  - Read Me -
                                  -----------

                            (for 128x128 scenario)



Compatible Simutrans Version
----------------------------

To find a compatible version of Simutrans exacutable for this scenario,
you can look at changelog128.txt



Where to find more information?
-------------------------------

pak128 home:
http://128.simutrans.com/

Simutrans forum:
http://forum.simutrans.com/



How Can You Help to Make This Game Better?
------------------------------------------

Join us in the forum, all forms of help are welcome.






                        -------------------------------
                        - Very Short Simutrans How-To -
                        -------------------------------



Please read this one page. It takes you just few minutes. Answering email
questions from you takes us time we can use to improve game. Please save us from
unimportant emails in your own interest.



Hints for all players
---------------------

�   It usually takes some years before lines get repaid. That is intention,
    not problem of your strategy.
�   Zoom is hidden under mouse wheel or PgUp or PgDown.



How do I:
---------

Turn the trees off?
Press "

Turn on / off station coverage (blue boxes)?
Press v.

Make buildings transparent (hidden)?
Press "

Turn on/off map grid?
Press #

Build one way track?
Select signal tool, multiply click on one place.

Speed the game up?
Use >> button in the menu.

Get more tips and tutorials?
Go to:
http://docs.simutrans.com
http://www.simutrans-tips.com
http://www.simutrans.com for more links


How do I become millionaire?
~~~~~~~~~~~~~~~~~~~~~~~~~~~~

Do not start big! Be careful and design system you can afford from starting
money.

Trains are intended to be long. 2-3 wagon train is usually lossy - except
for passenger units.

Press G (shift+g) and look at speed bonuses, goods with low bonus should go
slowly (cheaper), while goods with high bonus will pay much more for fast
service.

Most raw materials do not pay very well. Wood, stone, iron ore or grain are
not good stand alone money makers. You need to service whole industry tree
to make profit on higher level goods which pays much better. (look at income
graph)

Combine! Simutrans is about it. Make use of fact that goods can switch
vehicles on its route to destination and you get paid for each hop. Good
idea is to set high capacity train line and use trucks to collect materials
from larger area to keep trains busy.

Best paying goods among all are passengers. But it is difficult to setup
network big enough to attract enough of them. Only very experienced players
should try to start just with passengers, most players will rather setup
profiting goods service and use income to expend passenger transport.

Remember, number of passengers willing to use your service increases as
you cover more destinations. Do not let yourself to be annoyed because in the
very beginning you will hardly get a few travellers.


How can I contact you?
~~~~~~~~~~~~~~~~~~~~~~

To see main Simutrans webpage with many links and downloads go to:
http://www.simutrans.com/

To report bugs, discuss Simutrans etc. use forum:
http://forum.simutrans.com



Appendix
~~~~~~~~
This document was created by Tomas Kubes 29-Jan-2006
Corrections done by Vladimir Slavik


Thank you,
Tomas Kubes

updated: 25-Mar-2005
updated: 01-Jun-2005
updated: 29-Sep-2005
updated: 29-Jan-2006
updated: 07-Sep-2006