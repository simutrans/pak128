This archive contains everything needed to replicate the cotton fields from
pak128. Assuming you use the GIMP, of course!

First, custom brushes are needed -> folder brushes
Second, paint the fields with them -> folder images