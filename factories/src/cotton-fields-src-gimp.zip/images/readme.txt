These pictures consist of a few layers with different purposes. Let's go
through the list from bottom up:

BACKGROUND (EARTH) - this is where you want to put the bare earth; no size
    restrictions, since the next layer,

TRANSPARENCY MASK (BG) - cuts from it exactly the tile as is needed for game
    purposes.

PLANTS - what is says; paint here the vegetation you want on the field

TRANSPARENCY MASK (FG) - this cuts off the overlapping parts in foreground

BACK OVERLAY - here you must compensate for the overlapping parts of plants





So how you should use it: first, delete all in "back overlay".

Then paint what you want in "plants".

Turn on visibility of all layers.

Now you should see there are quite a few problems at the farther ends of tile.

You must restrict all "plants" pixels after end of tile to zero transparency.
That is complicated... if you do not do it, you will get "white edges" and
have to fix a lot of pixels by hand. Better use the automated way!

So: hide all layers, leave only "plants" and select it, switch to colour
channels, deselect and hide all except alpha. Now use tool "select by colour"
(hand with colourful cubes), threshold 0, disable antialiasing, allow selecting
empty regions. Then click empty (absolutely empty!) part of image. Invert
selection. Now you have selected all not-transparent parts of plants.

Change tool to "fuzzy select" (magic wand), again disable antialias and all
that options; change selection mode to "intersect" (small red icons, last
option). Switch to layer (not channel!) "transparency mask (bg)", show it and
click the upper part. Only the parts of plants poking out from the tile are
selected! This is really important selection, so save it to channel for later
reuse!

Right now, you want to fix alpha in this selected region, so again switch to
layer "plants" (still only alpha channel selected & visible!), and choose "fill
with fg color" - use black for that. Now reselect and show all colour channels.
The selected part should now contain only fully opaque colors. If it is black,
you missed something.

Finally... change to the topmost layer, use pencil tool with 1 pixel of e7ffff
and "hide" the ugly pixels you do not want visible in final product. You will
have to test a few times in game how it looks and which should be masked.

Some of the "opaquized" pixels are black and similar unwanted colours. You can
select the plants layer, use color selection tool to pick the unwanted colours,
then intersect with the saved selection in channel (now it's really handy),
switch back to "back overlay" layer and there fill this selection with e7ffff.
Thus you can get rid of the most obviously unwanted colours.

...done! Save as PNG, remove transparency, write DAT and enjoy in game.


PS: If you decide to change the plants, you will have to do this all again.
But if you only change the ground, you do NOT have to repeat this.