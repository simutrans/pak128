These are the brushes for painting cotton fields.

The .xcf are primary data - edit them, then save as .gih:
Spacing 10%
Name as you want
Cell size 2*4
One layer
One dimension (1)
7 items (rank?)
Random select

Then they go into GIMP shared data.

For me it was "C:\Program Files\GIMP-2.0\share\gimp\2.0\brushes" or
"C:\Documents and Settings\Vladim�r\.gimp-2.6\brushes".
Dunno where it's on linux... ask Mr. Google?

Finally paint with them. Don't use pencil with sharp edges, but brush. 100%
covering (fully opaque). One pass is not enough, you'll have to go over the
same line at least three times. If you want to make your life easier, use the
"paint straight line" feature - click, shift+click. Except these depict
vegetation, so switch on the second choice (jitter) to make them again more
random-like. The default value 20% was enough for me.

Sometimes jitter leaves "holes". You will have to pant over them manually,
there is nothing to do about that.

The rest is up to your artistic abilities, imagination and common sense...
